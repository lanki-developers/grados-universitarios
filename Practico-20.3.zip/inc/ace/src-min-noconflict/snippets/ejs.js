ace.define("ace/snippets/ejs",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="ejs"});                (function() {
                    ace.require(["ace/snippets/ejs"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            